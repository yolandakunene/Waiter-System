﻿namespace WaiteringSystem
{
    partial class EmployeeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Namelbl = new System.Windows.Forms.Label();
            this.Phonelbl = new System.Windows.Forms.Label();
            this.Paymentlbl = new System.Windows.Forms.Label();
            this.Hourlbl = new System.Windows.Forms.Label();
            this.Empidlbl = new System.Windows.Forms.Label();
            this.Tipslbl = new System.Windows.Forms.Label();
            this.IDlbl = new System.Windows.Forms.Label();
            this.wradioBttn = new System.Windows.Forms.RadioButton();
            this.rradioBttn = new System.Windows.Forms.RadioButton();
            this.hradioBttn = new System.Windows.Forms.RadioButton();
            this.IDtxt = new System.Windows.Forms.TextBox();
            this.Tipstxt = new System.Windows.Forms.TextBox();
            this.Hourstxt = new System.Windows.Forms.TextBox();
            this.Paymenttxt = new System.Windows.Forms.TextBox();
            this.Phonetxt = new System.Windows.Forms.TextBox();
            this.Nametxt = new System.Windows.Forms.TextBox();
            this.Empidtxt = new System.Windows.Forms.TextBox();
            this.CancelBttn = new System.Windows.Forms.Button();
            this.SubmitBttn = new System.Windows.Forms.Button();
            this.XtBttn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Namelbl
            // 
            this.Namelbl.AutoSize = true;
            this.Namelbl.Location = new System.Drawing.Point(89, 159);
            this.Namelbl.Name = "Namelbl";
            this.Namelbl.Size = new System.Drawing.Size(51, 20);
            this.Namelbl.TabIndex = 19;
            this.Namelbl.Text = "Name";
            // 
            // Phonelbl
            // 
            this.Phonelbl.AutoSize = true;
            this.Phonelbl.Location = new System.Drawing.Point(89, 217);
            this.Phonelbl.Name = "Phonelbl";
            this.Phonelbl.Size = new System.Drawing.Size(55, 20);
            this.Phonelbl.TabIndex = 18;
            this.Phonelbl.Text = "Phone";
            // 
            // Paymentlbl
            // 
            this.Paymentlbl.AutoSize = true;
            this.Paymentlbl.Location = new System.Drawing.Point(89, 274);
            this.Paymentlbl.Name = "Paymentlbl";
            this.Paymentlbl.Size = new System.Drawing.Size(75, 20);
            this.Paymentlbl.TabIndex = 17;
            this.Paymentlbl.Text = "Payment ";
            // 
            // Hourlbl
            // 
            this.Hourlbl.AutoSize = true;
            this.Hourlbl.Location = new System.Drawing.Point(89, 341);
            this.Hourlbl.Name = "Hourlbl";
            this.Hourlbl.Size = new System.Drawing.Size(52, 20);
            this.Hourlbl.TabIndex = 16;
            this.Hourlbl.Text = "Hours";
            // 
            // Empidlbl
            // 
            this.Empidlbl.AutoSize = true;
            this.Empidlbl.Location = new System.Drawing.Point(556, 102);
            this.Empidlbl.Name = "Empidlbl";
            this.Empidlbl.Size = new System.Drawing.Size(100, 20);
            this.Empidlbl.TabIndex = 15;
            this.Empidlbl.Text = "Employee ID";
            // 
            // Tipslbl
            // 
            this.Tipslbl.AutoSize = true;
            this.Tipslbl.Location = new System.Drawing.Point(90, 405);
            this.Tipslbl.Name = "Tipslbl";
            this.Tipslbl.Size = new System.Drawing.Size(42, 20);
            this.Tipslbl.TabIndex = 14;
            this.Tipslbl.Text = "Tips ";
            // 
            // IDlbl
            // 
            this.IDlbl.AutoSize = true;
            this.IDlbl.Location = new System.Drawing.Point(89, 102);
            this.IDlbl.Name = "IDlbl";
            this.IDlbl.Size = new System.Drawing.Size(26, 20);
            this.IDlbl.TabIndex = 13;
            this.IDlbl.Text = "ID";
            // 
            // wradioBttn
            // 
            this.wradioBttn.AutoSize = true;
            this.wradioBttn.Location = new System.Drawing.Point(444, 33);
            this.wradioBttn.Name = "wradioBttn";
            this.wradioBttn.Size = new System.Drawing.Size(80, 24);
            this.wradioBttn.TabIndex = 12;
            this.wradioBttn.TabStop = true;
            this.wradioBttn.Text = "Waiter";
            this.wradioBttn.UseVisualStyleBackColor = true;
            this.wradioBttn.CheckedChanged += new System.EventHandler(this.wradioBttn_CheckedChanged);
            // 
            // rradioBttn
            // 
            this.rradioBttn.AutoSize = true;
            this.rradioBttn.Location = new System.Drawing.Point(692, 33);
            this.rradioBttn.Name = "rradioBttn";
            this.rradioBttn.Size = new System.Drawing.Size(87, 24);
            this.rradioBttn.TabIndex = 11;
            this.rradioBttn.TabStop = true;
            this.rradioBttn.Text = "Runner";
            this.rradioBttn.UseVisualStyleBackColor = true;
            this.rradioBttn.CheckedChanged += new System.EventHandler(this.rradioBttn_CheckedChanged);
            // 
            // hradioBttn
            // 
            this.hradioBttn.Location = new System.Drawing.Point(194, 33);
            this.hradioBttn.Name = "hradioBttn";
            this.hradioBttn.Size = new System.Drawing.Size(142, 24);
            this.hradioBttn.TabIndex = 31;
            this.hradioBttn.Text = "HeadWaiter";
            this.hradioBttn.CheckedChanged += new System.EventHandler(this.hradioBttn_CheckedChanged_1);
            // 
            // IDtxt
            // 
            this.IDtxt.Location = new System.Drawing.Point(178, 102);
            this.IDtxt.Name = "IDtxt";
            this.IDtxt.Size = new System.Drawing.Size(237, 26);
            this.IDtxt.TabIndex = 20;
            // 
            // Tipstxt
            // 
            this.Tipstxt.Location = new System.Drawing.Point(178, 405);
            this.Tipstxt.Name = "Tipstxt";
            this.Tipstxt.Size = new System.Drawing.Size(237, 26);
            this.Tipstxt.TabIndex = 21;
            // 
            // Hourstxt
            // 
            this.Hourstxt.Location = new System.Drawing.Point(178, 338);
            this.Hourstxt.Name = "Hourstxt";
            this.Hourstxt.Size = new System.Drawing.Size(237, 26);
            this.Hourstxt.TabIndex = 22;
            // 
            // Paymenttxt
            // 
            this.Paymenttxt.Location = new System.Drawing.Point(178, 268);
            this.Paymenttxt.Name = "Paymenttxt";
            this.Paymenttxt.Size = new System.Drawing.Size(237, 26);
            this.Paymenttxt.TabIndex = 30;
            // 
            // Phonetxt
            // 
            this.Phonetxt.Location = new System.Drawing.Point(178, 217);
            this.Phonetxt.Name = "Phonetxt";
            this.Phonetxt.Size = new System.Drawing.Size(237, 26);
            this.Phonetxt.TabIndex = 24;
            // 
            // Nametxt
            // 
            this.Nametxt.Location = new System.Drawing.Point(178, 159);
            this.Nametxt.Name = "Nametxt";
            this.Nametxt.Size = new System.Drawing.Size(478, 26);
            this.Nametxt.TabIndex = 25;
            // 
            // Empidtxt
            // 
            this.Empidtxt.Location = new System.Drawing.Point(708, 102);
            this.Empidtxt.Name = "Empidtxt";
            this.Empidtxt.Size = new System.Drawing.Size(208, 26);
            this.Empidtxt.TabIndex = 26;
            // 
            // CancelBttn
            // 
            this.CancelBttn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.CancelBttn.Location = new System.Drawing.Point(522, 474);
            this.CancelBttn.Name = "CancelBttn";
            this.CancelBttn.Size = new System.Drawing.Size(91, 35);
            this.CancelBttn.TabIndex = 27;
            this.CancelBttn.Text = "Cancel";
            this.CancelBttn.UseVisualStyleBackColor = true;
            this.CancelBttn.Click += new System.EventHandler(this.CancelBttn_Click);
            // 
            // SubmitBttn
            // 
            this.SubmitBttn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.SubmitBttn.Location = new System.Drawing.Point(708, 474);
            this.SubmitBttn.Name = "SubmitBttn";
            this.SubmitBttn.Size = new System.Drawing.Size(90, 35);
            this.SubmitBttn.TabIndex = 28;
            this.SubmitBttn.Text = " Submit";
            this.SubmitBttn.UseVisualStyleBackColor = true;
            this.SubmitBttn.Click += new System.EventHandler(this.SubmitBttn_Click_1);
            // 
            // XtBttn
            // 
            this.XtBttn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.XtBttn.Location = new System.Drawing.Point(889, 474);
            this.XtBttn.Name = "XtBttn";
            this.XtBttn.Size = new System.Drawing.Size(100, 35);
            this.XtBttn.TabIndex = 29;
            this.XtBttn.Text = "Exit";
            this.XtBttn.UseVisualStyleBackColor = true;
            this.XtBttn.Click += new System.EventHandler(this.XtBttn_Click_1);
            // 
            // EmployeeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1061, 530);
            this.Controls.Add(this.XtBttn);
            this.Controls.Add(this.SubmitBttn);
            this.Controls.Add(this.CancelBttn);
            this.Controls.Add(this.Empidtxt);
            this.Controls.Add(this.Nametxt);
            this.Controls.Add(this.Phonetxt);
            this.Controls.Add(this.Paymenttxt);
            this.Controls.Add(this.Hourstxt);
            this.Controls.Add(this.Tipstxt);
            this.Controls.Add(this.IDtxt);
            this.Controls.Add(this.Namelbl);
            this.Controls.Add(this.Phonelbl);
            this.Controls.Add(this.Paymentlbl);
            this.Controls.Add(this.Hourlbl);
            this.Controls.Add(this.Empidlbl);
            this.Controls.Add(this.Tipslbl);
            this.Controls.Add(this.IDlbl);
            this.Controls.Add(this.wradioBttn);
            this.Controls.Add(this.rradioBttn);
            this.Controls.Add(this.hradioBttn);
            this.Name = "EmployeeForm";
            this.Text = " EmployeeForm";
            this.Activated += new System.EventHandler(this.EmployeeForm_Activated);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.EmployeeForm_FormClosed);
            this.Load += new System.EventHandler(this.EmployeeForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Namelbl;
        private System.Windows.Forms.Label Phonelbl;
        private System.Windows.Forms.Label Paymentlbl;
        private System.Windows.Forms.Label Hourlbl;
        private System.Windows.Forms.Label Empidlbl;
        private System.Windows.Forms.Label Tipslbl;
        private System.Windows.Forms.Label IDlbl;
        private System.Windows.Forms.RadioButton wradioBttn;
        private System.Windows.Forms.RadioButton rradioBttn;
        private System.Windows.Forms.RadioButton hradioBttn;
        private System.Windows.Forms.TextBox IDtxt;
        private System.Windows.Forms.TextBox Tipstxt;
        private System.Windows.Forms.TextBox Hourstxt;
        private System.Windows.Forms.TextBox Paymenttxt;
        private System.Windows.Forms.TextBox Phonetxt;
        private System.Windows.Forms.TextBox Nametxt;
        private System.Windows.Forms.TextBox Empidtxt;
        private System.Windows.Forms.Button CancelBttn;
        private System.Windows.Forms.Button SubmitBttn;
        private System.Windows.Forms.Button XtBttn;
    }
}