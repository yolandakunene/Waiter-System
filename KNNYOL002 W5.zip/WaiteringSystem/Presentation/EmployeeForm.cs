﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using WaiteringSystem.Business;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static WaiteringSystem.Business.Role;

namespace WaiteringSystem
{
    public partial class EmployeeForm : Form
    {
        private Employee employee;
        private EmployeeController employeeController;
        private Role.RoleType roleValue;
        public bool employeeFormClosed;

        public Role.RoleType RoleValue
        {
            get { return roleValue; }
            set { roleValue = value; }
        }

        #region Constructor
        public EmployeeForm(EmployeeController aController)
        {
            InitializeComponent();
            employeeFormClosed = false;

            employeeController = aController;
        }
        #endregion
        // EmployeeController  aController
        #region Utility Methods
        public void Showall(bool value, Role.RoleType roleType)
        {
            IDlbl.Visible = value;
            Empidlbl.Visible = value;
            Namelbl.Visible = value;
            Phonelbl.Visible = value;
            Paymentlbl.Visible = value;
            Hourlbl.Visible = value;
            Tipslbl.Visible = value;

            IDtxt.Visible = value;  
            Empidtxt.Visible = value;
            Nametxt.Visible = value;
            Phonetxt.Visible = value;
            Paymenttxt.Visible = value; 
            Hourstxt.Visible = value;
            Tipstxt.Visible = value;

            SubmitBttn.Visible = value;
            CancelBttn.Visible = value;
            XtBttn.Visible = value;

            if (!(value))
            {
                //hradioBttn.Checked = false;
                hradioBttn.Checked = false;
                //wradioBttn.Checked = false;
                wradioBttn.Checked = false;
                //rradioBttn.Checked = false;
                rradioBttn.Checked = false;
            }
            //visibility for controls associated with waiter and runner radio buttons
            if (wradioBttn.Checked | rradioBttn.Checked)
            {

                Tipslbl.Visible = value;
                Tipstxt.Visible = value;
                Hourlbl.Visible = value;
                Hourstxt.Visible = value;
            }
            else
            {
                Tipslbl.Visible = false;
                Tipstxt.Visible = false;
                Hourlbl.Visible = false;
                Hourstxt.Visible = false;
            }

        }
        public void Clearall()
        {
            //Clear all the controls
            IDtxt.Clear();
            Empidtxt.Clear();
            Nametxt.Clear();
            Phonetxt.Clear();
            Tipstxt.Clear();
            Paymenttxt.Clear();
            Hourstxt.Clear();
       
        }
        public void PopulateObject(Role.RoleType RoleType)
        {
            //reference to the roles classes
            HeadWaiter headW;
            Waiter waiter;
            Runner runner;

            //an instance of the employee object
            employee = new Employee(RoleType);

            //assign the controls fields to the employee object fields
            employee.ID = IDtxt.Text;
            employee.EmployeeID = Empidtxt.Text;
            employee.Name = Nametxt.Text;
            employee.Telephone = Phonetxt.Text;

            switch (employee.role.getRoleValue)
            {
                case Role.RoleType.Headwaiter:
                    headW = (HeadWaiter)(employee.role);
                    headW.SalaryAmount = decimal.Parse(Paymenttxt.Text);
                    break;
                case Role.RoleType.Waiter:
                    waiter = (Waiter)(employee.role);
                    waiter.getRate = decimal.Parse(Paymenttxt.Text);
                    waiter.getShifts = Int32.Parse(Hourstxt.Text);
                    waiter.getTips = decimal.Parse(Tipstxt.Text);
                    break;
                case Role.RoleType.Runner:
                    runner = (Runner)(employee.role);
                    runner.getRate = decimal.Parse(Paymenttxt.Text);
                    runner.getShifts = Int32.Parse(Hourstxt.Text);
                    runner.getTips = decimal.Parse(Tipstxt.Text);
                    break;
            }

        }
        #endregion

        

        #region Form Events
        private void EmployeeForm_Load(object sender, EventArgs e)
        {
            //call show all method when the form loads
            Showall(false, roleValue);
            //instance of the employeeController class
            //employeeController = new EmployeeController();
        }
        private void EmployeeForm_Activated(object sender, EventArgs e)
        {
            hradioBttn.Checked = false;
            Showall(false, roleValue);
        }
        #endregion

        #region Radio Button CheckedChanged Events
        private void hradioBttn_CheckedChanged_1(object sender, EventArgs e)
        {
            this.Text = "Add Head Waiter";
            roleValue = Role.RoleType.Headwaiter;
            Paymentlbl.Text = "Salary";
            Showall(true, roleValue);
            IDtxt.Focus();
        }
        private void wradioBttn_CheckedChanged(object sender, EventArgs e)
        {
            this.Text = "Add Waiter";
            roleValue = Role.RoleType.Waiter;
            Paymentlbl.Text = "Rate";
            Showall(true, roleValue);
            IDtxt.Focus();
        }
        private void rradioBttn_CheckedChanged(object sender, EventArgs e)
        {
            this.Text = "Add Runner";
            roleValue = Role.RoleType.Runner;
            Paymentlbl.Text = "Rate";
            Showall(true, roleValue);
            IDtxt.Focus();
        }
        #endregion


        #region Button Click events
        private void SubmitBttn_Click_1(object sender, EventArgs e)
        {
            PopulateObject(Role.RoleType.Headwaiter);
            PopulateObject(Role.RoleType.Waiter);
            PopulateObject(Role.RoleType.Runner);
            MessageBox.Show("The record will be submitted to the database", "Submitted", MessageBoxButtons.OK);
            employeeController.DataMaintenance(employee);
            employeeController.FinalizeChanges(employee);
            //call the clear all method to clear controls
            Clearall();
            //call the show all method
            Showall(false, roleValue);
        }
        private void XtBttn_Click_1(object sender, EventArgs e)
        {
            this.Close();
            employeeFormClosed = true;
        }
        private void CancelBttn_Click(object sender, EventArgs e)
        {
            Clearall();
            Showall(false, roleValue);
        }



        #endregion

        private void EmployeeForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            employeeFormClosed = true;
        }
    }
}
