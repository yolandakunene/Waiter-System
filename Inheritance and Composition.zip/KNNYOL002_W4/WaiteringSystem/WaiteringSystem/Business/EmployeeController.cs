﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WaiteringSystem.Data;

namespace WaiteringSystem.Business
{
    internal class EmployeeController
    {
        #region Declaring data member 
        //declaring  EmployeeDB  reference 
        EmployeeDB employeeDB;
        // Declare a collection of employees 
        Collection<Employee> employees;
        #endregion
        #region constructor
        public EmployeeController()
        {
            employeeDB = new EmployeeDB();
            employees = employeeDB.AllEmployee;
        }
        #endregion
        #region Database Communication 
        public void DataMaintenance(Employee anEmp)
        {
            employeeDB.DataSetChange(anEmp);
            employees.Add(anEmp);
        }
        public bool FinalizeChanges(Employee employee)
        {
            return employeeDB.UpdateDataSource(employee);
            #endregion

        }
    }
}
