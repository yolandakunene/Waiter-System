﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using WaiteringSystem.Business;

namespace WaiteringSystem.Data
{
    internal class EmployeeDB : DB
    #region Declaring Data Member
    // declare the data member for all the roles type
    {
        private string _table1 = "headWaiter";
        private string _sqlLocal1 = "SELECT  * FROM HeadWaiter ";

        private string _table2 = "Waiter";
        private string _sqlLocal2 = "SELECT  * FROM Waiter ";

        private string _table3 = "Runner";
        private string _sqlLocal3 = "SELECT  * FROM  Runner  ";

        private string _table0 = "No role ";
        private string _sqlLocal0 = "SELECT  * FROM DB() ";

        // declare a collection employees of employees 
        private Collection<Employee> employees;
        #endregion

        #region  Property Methods
        //add get method AllEmployees to return a collction 
        public Collection<Employee> AllEmployee
        {
            get { return employees; }
        }
        #endregion

        #region Constructor 
        public EmployeeDB() : base()
        {
            // Default constructor that create the instance of the  employee collection  and fill the database 
            employees = new Collection<Employee>();
            FillDataSet(_sqlLocal0, _table0);
            Add2Collection(_table0);
            FillDataSet(_sqlLocal1, _table1);
            Add2Collection(_table1);
            FillDataSet(_sqlLocal2, _table2);
            Add2Collection(_table2);
            FillDataSet(_sqlLocal3, _table3);
            Add2Collection(_table3);
        }
        #endregion

        #region Utility Methods 
        // return the database using  base 
        public DataSet GetDataSet()
        {
            return dsMain;

        }
        public void Add2Collection(string atable)
        {
            //Declare a reference to a myRow object(Data type DataRow) and assign it null
            DataRow myRow;
            myRow = null;
            Employee anEmp;
            //declare reference to each of the derived classes of Role as follows: 
            HeadWaiter headW;
            Waiter waiter;
            Runner runner;
            //Declare roleValue and initialise it to No role
            Role.RoleType roleValue = Role.RoleType.NoRole;

            switch (atable)
            {
                case "HeadWaiter":
                    roleValue = Role.RoleType.Headwaiter;
                    break;
                case "Waiter":
                    roleValue = Role.RoleType.Waiter;
                    break;
                case "Runner":
                    roleValue = Role.RoleType.Runner;
                    break;
            }
            foreach (DataRow myRow_loopVariable in dsMain.Tables[atable].Rows)
            {
                myRow = myRow_loopVariable;
                if (myRow.RowState != DataRowState.Deleted)
                {
                    anEmp = new Employee(roleValue);
                    anEmp.ID = Convert.ToString(myRow["ID"]).TrimEnd();
                    anEmp.EmployeeID = Convert.ToString(myRow["EmployeeID"]).TrimEnd();
                    anEmp.Name = Convert.ToString(myRow["Name"]).TrimEnd();
                    anEmp.Telephone = Convert.ToString(myRow["Telephone"]).TrimEnd();
                    anEmp.role.getRoleValue = (Role.RoleType)Convert.ToByte(myRow["Role"]);

                    switch (anEmp.role.getRoleValue)
                    {
                        case Role.RoleType.Headwaiter:
                            headW = (HeadWaiter)anEmp.role;
                            headW.SalaryAmount = Convert.ToDecimal(myRow["Salary"]);
                            break;

                        case Role.RoleType.Waiter:
                            waiter = (Waiter)anEmp.role;
                            waiter.getRate = Convert.ToDecimal(myRow["DayRate"]);
                            waiter.getShifts = Convert.ToInt32(myRow["NoOfShifts"]);
                            break;
                        case Role.RoleType.Runner:
                            runner = (Runner)anEmp.role;
                            runner.getRate = Convert.ToDecimal(myRow["DayRate"]);
                            runner.getShifts = Convert.ToInt32(myRow["NoOfShifts"]);
                            break;

                    }
                    employees.Add(anEmp);
                }
               
            }

        }
        public void FillRow(DataRow aRow, Employee anEmp)
        {
            HeadWaiter headwaiter;
            Runner runner;
            Waiter waiter;
            aRow["ID"] = anEmp.ID;
            aRow["EmpID"] = anEmp.EmployeeID;
            aRow["Name"] = anEmp.Name;
            aRow["Phone"] = anEmp.Telephone;
            aRow["Role"] = (byte)anEmp.role.getRoleValue;

            switch (anEmp.role.getRoleValue)
            {
                case Role.RoleType.Headwaiter:
                    headwaiter = (HeadWaiter)anEmp.role;
                    aRow["Salary"] = headwaiter.SalaryAmount;
                    break;
                case Role.RoleType.Waiter:
                    waiter = (Waiter)anEmp.role;
                    aRow["DayRate"] = waiter.getRate;
                    aRow["NoOfShifts"] = waiter.getShifts;
                    aRow["Tips"] = waiter.getTips;
                    break;
                case Role.RoleType.Runner:
                    runner = (Runner)anEmp.role;
                    aRow["DayRate"] = runner.getRate;
                    aRow["NoOfShifts"] = runner.getShifts;
                    break;
                   
            }
        }
        #endregion
        #region  Database Operations CRUD 
        public void DataSetChange(Employee anEmp)
        {
            DataRow sRow; 
                sRow= null;
            string dataTable;
            dataTable= _table1;
            switch (anEmp.role.getRoleValue)
            {
                case Role.RoleType.Headwaiter:
                    dataTable = _table1;
                    break;
                case Role.RoleType.Waiter:
                    dataTable = _table2;
                    break;
                case Role.RoleType.Runner:
                    dataTable = _table3;
                    break;
            }
            sRow = dsMain.Tables[dataTable].NewRow();
            FillRow(sRow, anEmp);
            //Add to the dataset
            dsMain.Tables[dataTable].Rows.Add(sRow);
        }
        #endregion
        #region Build Parameters, Create Commands & Update database
        private void Build_INSERT_Parameters(Employee anEmp)
        {
        
            SqlParameter param = default(SqlParameter);
            param = new SqlParameter("@ID", SqlDbType.NVarChar, 15, "ID");
         
            daMain.InsertCommand.Parameters.Add(param);

            param = new SqlParameter("@EMPID", SqlDbType.NVarChar, 10, "EMPID");
            daMain.InsertCommand.Parameters.Add(param);

            param = new SqlParameter("@Name", SqlDbType.NVarChar, 100, "Name");
            daMain.InsertCommand.Parameters.Add(param);

            param = new SqlParameter("@Phone", SqlDbType.NVarChar, 15, "Phone");
            daMain.InsertCommand.Parameters.Add(param);

            param = new SqlParameter("@Role", SqlDbType.TinyInt, 1, "Role");
            daMain.InsertCommand.Parameters.Add(param);
            switch (anEmp.role.getRoleValue)
            {
                case Role.RoleType.Headwaiter:
                    param = new SqlParameter("@Salary", SqlDbType.Money, 8, "Salary");
                    daMain.InsertCommand.Parameters.Add(param);
                    break;
                case Role.RoleType.Waiter:

                    param = new SqlParameter("@DayRate", SqlDbType.Money, 8, "DayRate");
                    daMain.InsertCommand.Parameters.Add(param);

                    param = new SqlParameter("@NoOfShifts", SqlDbType.SmallInt, 4, "NoOfShifts");
                    daMain.InsertCommand.Parameters.Add(param);

                    param = new SqlParameter("@Tips", SqlDbType.Money, 8, "Tips");
                    daMain.InsertCommand.Parameters.Add(param);
                    break;
                case Role.RoleType.Runner:
                    param = new SqlParameter("@DayRate", SqlDbType.Money, 8, "DayRate");
                    daMain.InsertCommand.Parameters.Add(param);

                    param = new SqlParameter("@NoOfShifts", SqlDbType.SmallInt, 4, "NoOfShifts");
                    daMain.InsertCommand.Parameters.Add(param);
                    break;
            }
        }

        private void Create_INSERT_Command(Employee anEmp)
        {
            switch (anEmp.role.getRoleValue)
            {
                case Role.RoleType.Headwaiter:
                    daMain.InsertCommand = new SqlCommand("INSERT into HeadWaiter (ID, EMPID, Name, Phone, Role, Salary) +" +
                        "VALUES (@ID, @EmpID, @Name, @Phone, @Role, @Salary)", cnMain);
                    break;
                case Role.RoleType.Waiter:
                  
                    daMain.InsertCommand = new SqlCommand("INSERT into Waiter (ID, EMPID, Name, Phone, Role, DayRate, NoOfShifts,Tips) +" +
                        "VALUES (@ID, @EmpID, @Name, @Phone, @Role, @DayRate, @NoOfShifts, @Tips)", cnMain);
                    break;
                case Role.RoleType.Runner:
                    daMain.InsertCommand = new SqlCommand("INSERT into Runner (ID, EMPID, Name, Phone, Role, DayRate, NoOfShifts) +" +
                        "VALUES (@ID, @EmpID, @Name, @Phone, @Role, @DayRate, @NoOfShifts)", cnMain);
                    break;
            }
            Build_INSERT_Parameters(anEmp);
        }

        public bool UpdateDataSource(Employee anEmp)
        {
            bool success = true;
            Create_INSERT_Command(anEmp);
            switch (anEmp.role.getRoleValue)
            {
                case Role.RoleType.Headwaiter:
                    success = UpdateDataSource(_sqlLocal1, _table1);
                    break;
                case Role.RoleType.Waiter:
                    success = UpdateDataSource(_sqlLocal2, _table2);
                    break;
                case Role.RoleType.Runner:
                    success = UpdateDataSource(_sqlLocal3, _table3);
                    break;
            }
            return success;
        }

        #endregion

    }
}
