﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WaiteringSystem
{
    public abstract class Person
    { 
        #region data member 

        /* hide the implementation details and display only essential features of the object.it also prevent class from being instiated*/
        private string _Name;
        private string _ID;
        private string _Phone;
        #endregion

        #region  property 
        public String Name
        { 
            get { return _Name ; } 
            set { _Name = value; }
        }

        public String ID
        {
            get { return _ID; }
            set { _ID = value; }
        }
        public string Phone
        {
            get { return _Phone; }
            set { _Phone = value; }
        }
        #endregion

        #region Constuctor 
        public Person()
        {
            _Name = "";
            _ID = "";
            _Phone = "";
        }
        public Person(string newname, string newid, string newphone)
        {
            _Name = newname;
            _ID = newid;
            _Phone = newphone;
        }
        public virtual string InfoToString()
        {
            return _Name + _Phone;
        }
        #endregion
    }


}