﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using WaiteringSystem.business;

namespace WaiteringSystem
{
    public  class Employee : Person
    {
        /*  public Employee():base(){}
          public Employee(string newname, string newid, string newphone) : base(string newname, string newid, string newphone) { }
        */
        private int employeeID;
        private string employeeRole ;
        public int EmployeeID
        {
            get { return employeeID; }
            set { employeeID = value; }
        }
        public string EmployeeRole
        {
            get { return employeeRole; }
            set { employeeRole = value;}
        }
        public override string ToString()
        {
            return Name + Phone;
            //Waiter waiter = new Waiter();
            //waiter.Tips = Convert.ToDouble(txtTips.Text);
        }
        public Employee(Role roleValue)
        {
            // assigning employee roles
            switch(roleValue.RoleValue)
            {
                case 1:
                    employeeRole = new Headwaiter().ToString();
                    break;
                case 2:
                    employeeRole = new Waiter().ToString();
                    break;
                case 3:
                    employeeRole = new Runner ().ToString();
                    break;
                default:
                    employeeRole = new Role().ToString();
                    break;

            }
        }

    }
}
