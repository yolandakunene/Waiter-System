﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace WaiteringSystem.business
{
    internal class Runner: Role
    {
        private double _salary;
        private double _tips;
        private double _rate;
        private int _noOfShits;
        public double Salary
        {
            get { return _salary; }
            set { _salary = value; }
        }
        public double Tips
        {
            get { return _tips; }
            set { _tips = value; }
        }
        public double Rate
        {
            get { return _rate; }
            set { _rate = value; }
        }
        public int NoOfShits
        {
            get { return _noOfShits; }
            set { _noOfShits = value; }
        }
        public Runner() : base()
        {
            RoleValue = (int)RoleType.Runner;
            Description = RoleValue.ToString();
        }
        public override double Payment()
        {
            return Rate * NoOfShits;
        }
    }
}
