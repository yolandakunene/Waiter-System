﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WaiteringSystem.business
{
    internal class Waiter: Role 
    {
        private double _salary;
        private double _tips;
        private double _rate;
        private int _noOfShits;

        public double Salary
        {
            get { return _salary; } 
            set { _salary = value; }    
        }
        public double Tips
        {   
            get { return _tips; } 
            set {  _tips = value; } 
        }
        public double Rate
        {
            get { return _rate; } 
            set { _rate = value; }
        }
        public int NoOfShits
        { 
            get { return _noOfShits; }
            set { _noOfShits = value;}
        }
        public Waiter () : base()
        {
            RoleValue = (int)RoleType.Waiter;
            Description = RoleValue.ToString();
            _salary = 0;
            _tips = 0;
            _rate = 0;
            _noOfShits = 0;
        }
        public override double Payment()
        {
            return Rate * NoOfShits;
        }
        public override double Payment(double tips)
        { 
            
            tips = _tips;
            return (Rate * NoOfShits) + tips;
        }

    }

}
