﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Security.Permissions;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace WaiteringSystem.business
{
    public class Role
    {
        /* 
        public enum RoleId
        {
            _Runner,
            _Waiter,
            _HeadWaiter,
            _NoRole,
        }
        // can i use assign value like this in the headwaiter class 
        RoleValue = (RoleValue)RoleType.Headwaiter;?
        if not how can i do it if possible 
        
         */


        public enum RoleType 
        {
            Runner = 3,
            Waiter = 2,
            Headwaiter = 1,
            NoRole = 0,
        }
        private string _description;
        private int _roleValue;

        public string Description 
        {
            get { return _description; }
            set { _description = value; }
        }
        public int RoleValue
        {
            get { return _roleValue; }
            set { _roleValue = value; }
        }
        public Role()
        {
            RoleValue = (int)RoleType.NoRole;
            _description = RoleValue.ToString();
        }
        public virtual double Payment()
        {
            return 0;

        }

        public virtual double Payment(double amount)
        {
            return 0;
        }
    } 
}
    
       
