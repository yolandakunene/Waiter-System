﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static WaiteringSystem.business.Role;

namespace WaiteringSystem.business
{
    internal class Headwaiter: Role
    {
        private double _salary;

        public double Salary
        {
            get { return _salary; }
            set { _salary = value; }
        }
        public Headwaiter() : base()
        {
            RoleValue = (int)RoleType.Headwaiter;
            Description = RoleValue.ToString();
            _salary = 0;
        }
        public override double Payment()
        {
            return _salary;
        }
    }
}
